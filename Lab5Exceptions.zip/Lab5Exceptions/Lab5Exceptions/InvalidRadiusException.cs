﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5Exceptions
{
    public class InvalidRadiusException : Exception
    {
        public InvalidRadiusException(string message) : base(message){ }
        public override string ToString()
        {
            return "Invalid Radius: " + Message;
        }
    }
}
