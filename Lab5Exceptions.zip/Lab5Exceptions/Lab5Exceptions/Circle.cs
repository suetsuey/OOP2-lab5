﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5Exceptions
{
    internal class Circle
    {
        private double _radius;
        public double Radius
        {
            get
            {
                return _radius;
            }
            set
            {
                if (value <= 0)
                    throw new InvalidRadiusException("Radius cannot be 0 or negative.");
                _radius = value;
            }
        }

        public Circle(double radius)
        {
            //if (radius < 0 || double.IsInfinity(radius))
                //throw new InvalidRadiusException("Radius cannot be negative or infinity.");
            Radius = radius;
        }

        public double Area()
        {
            //return Math.PI * Radius;
            return Math.PI * Math.Pow(Radius, 2);
        }

        public override string ToString()
        {
            return "Area: " + this.Area();
        }

    }
}
